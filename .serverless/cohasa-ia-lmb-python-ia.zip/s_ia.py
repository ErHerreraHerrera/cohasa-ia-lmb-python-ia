import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='mhanania',
    application_name='cohasa-ia',
    app_uid='r0sFJmrw2DGxC28c3G',
    org_uid='c4ef9189-cd44-4397-9b5f-4d52cb6a6a50',
    deployment_uid='583f7d0c-ddcc-485e-a592-4f52435f3fd1',
    service_name='cohasa-ia-lmb-python-ia',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'cohasa-ia-lmb-python-ia-dev-ia', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.ia')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
